<template>
  <div>
    <div>
      <h1>게시판</h1> 
      <div>
      <p>
        <el-input placeholder="검색어를 입력해주세요" v-model="searchVal" style="width:35%;" @keypress.enter="buttonSelect" > </el-input>&nbsp;&nbsp;
        <el-button type="info" icon="el-icon-search"  @click="buttonSelect">Search</el-button>
        <el-button type="primary" icon="el-icon-search" @click="boardWrite"  >Write</el-button>
      </p>
      </div>
      <div v-if="openList">
        <ag-grid-vue style="width: 800px; height: 500px; margin:auto;"
          class="ag-theme-alpine"
          :columnDefs="columnDefs"
          :rowData="rowData"
          rowSelection="multiple"
          @rowClicked="rowClicked"
          >
        </ag-grid-vue><br><br>
      </div>
      <div v-if="openSearch" >
        <ag-grid-vue style="width: 800px; height: 500px; margin:auto;"
          class="ag-theme-alpine"
          :columnDefs="columnDefs"
          :rowData="rowData"
          rowSelection="multiple"
          @rowClicked="rowClicked"
          :pagination="true"
          >
        </ag-grid-vue>
      </div><br><br>
    </div>
    <div>
      <board-view 
      v-if="detailFlag"
      :view-data="viewData"   
      :detail-flag="detailFlag" 
      :view-detail="viewDetail"

      @detailClose="detailClose"
      @updateMove="updateMove"
      @detailDelete="detailDelete"
      />
    </div>
  </div>
</template>

<script>
  import { AgGridVue } from "ag-grid-vue";
  import page from "@/views/page.vue"
  import boardView from "@/views/boardView.vue"

    export default {
      name:"boardList",
      components:{
      AgGridVue,
      page,
      boardView,
    },
  data(){
    return{
      columnDefs: null,   //열
      rowData: [],    //행

      openList:false,     //전체 리스트
      openSearch:false,   //검색 리스트 
      
      detailFlag: false,   //상세보기 창
      viewDetail:null,

      viewData:null,     //상세보기 데이터
      searchVal:'',    //검색 파라미터 값

      pageLimit : 10,    // 처음 몇번쨰 부터
      pageOffset : 0,    // 몇개 출력

      // startPageIndex : 0,
      // listRowCount : 5,

    }
  },
    created(){
      this.initComponent();
    // this.ag_grid ();
  },
    beforeMount() {
      this.openList=true;
      this.openSearch=false;
    },
   
  methods: {
    initComponent(){
      this.columnDefs = [
        {
          headerName: 'ag_grid_1',
            children:[
              { headerName: "글번호", field: 'id' ,  },//checkboxSelection: checkboxSelection,
              { headerName: "제목", field: 'title',  },
            ]
        },
        {
          headerName: 'ag_grid_2',
            children:[
              { headerName: "작성자", field: 'writer' },
              { headerName: "작성일", field: 'reg_date', } //type: 'rightAligned' 
          ]
        }
      ];
      //  this.$router.push({path:'/boardList',query:this.body})
        console.log(this.currentPage)
          this.$axios.get('/api/pageList/',{
            params: { 
              limit: ((this.currentPage-1)*this.pageSize),
              offset: this.pageSize, 
            }
          })
            .then(response=>{
              console.log(response)
            this.rowData = response.data;
            cibsike
            this.total= response.data.length;
            console.log(this.total)
            }) 
              .catch(() => {
                alert('에러가  발생했습니다.');
          })
         
     },

        //  if(this.currentPage<=0){
        //   this.$axios.get('/api/pageList/',{
        //     params: { 
        //       limit: this.currentPage=1,
        //       offset: this.pageSize, 
        //     }
        //   })        
        // }else{
        //   this.$axios.get('/api/pageList/',{
        //     params: { 
        //       limit: ((this.currentPage-1)*this.pageSize),
        //       offset: this.pageSize, 
        //     }
        //     .then(response=>{
        //       console.log(response)
        //     this.rowData = response.data;
        //     }) 
        //       .catch(() => {
        //         alert('에러가  발생했습니다.');
        //     })
        //   })
        // }

    // totalCount(){
    //   this.$axios.get('/api/boardCount')
    //   .then(response=>{
    //     console.log(response.data)
    //     this.total=response.data
    //   });
    //리스트 출력
    ag_grid(){
      this.columnDefs = [
        {
          headerName: 'ag_grid_1',
            children:[
              { headerName: "글번호", field: 'id' ,  },//checkboxSelection: checkboxSelection,
              { headerName: "제목", field: 'title',  },
            ]
        },
        {
          headerName: 'ag_grid_2',
            children:[
              { headerName: "작성자", field: 'writer' },
              { headerName: "작성일", field: 'reg_date', } //type: 'rightAligned' 
          ]
        }
      ];
      this.$axios.get('/api/boardListAll')
      .then(response=>{
        console.log("===================== 전체 수")
        console.log(response.data.length)
        this.rowData = response.data;
        this.total= response.data.length;
        
      });
      // this.totalCount();
    },

    //버튼: 글작성
    boardWrite(){
      this.$router.push({path:'/boardWrite'})
    },

    //게시글 상세보기
    rowClicked(row) {
      console.log(row);
      console.log(row.data.id);

      this.viewData=row.data;   //boardView (상세보기)
      console.log("==================")
      console.log(this.viewData)

      this.viewDetail=row.data;   //boardView2 (상세보기2)
      console.log("==================")
      console.log(this.viewDetail)

      this.$axios.get('/api/boardView/'+row.data.id)
        .then((response)=>{
          this.viewData=response;
          console.log("==================")
          console.log(this.viewData)


          // this.$router.push({path:'/boardView2'+row.data.id})
          // this.$router.push({path:'/boardView2',query:{
          //   id:"1",
          //   title:"1",
          //   contents:"1",
          //   writer:"1"
          // }})

          // this.$router.push({path:'/boardList'})
          
          this.detailFlag = true;
        })
        .catch(function (e) {
          console.error(e)                
        })
  },

    //검색버튼
    buttonSelect(){
      this.detailFlag=false;
      if (this.searchVal==''||this.searchVal==null) {
        this.ag_grid();            
      } else {
        this.$axios.get('/api/boardSearch',{
          params:{
            searchVal:this.searchVal
          }
        })
          .then((response) => { 
            console.log("버튼검색:::::::::"+ response)
            this.rowData = response.data
            this.openList=false;
            this.openSearch=true;
          })
          .catch(function (e) {
            console.error(e)
          })
    }
    },

    // $emit 상속
    detailClose(){
      this.detailFlag=false;
    },
    updateMove(){
      this.detailFlag=false;
      this.ag_grid();
    },
    detailDelete(){
      this.detailFlag=false;
      this.ag_grid();         
    },
  }
}
</script>