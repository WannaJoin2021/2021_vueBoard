<template>
  <div>
<div v-show="!updateFlag" >
      <el-row :gutter="20">
        <el-col class="test grid-content bg-purple" :offset="4" :span="6">제목</el-col>
        <el-col class="test " :span="10" v-show="!updateFlag">
         {{ viewDataTitle  }}</el-col>
      </el-row>
      <el-row :gutter="20">
        <el-col class="test grid-content bg-purple" :offset="4" :span="6">작성자</el-col>
        <el-col class="test" :span="10" v-show="!updateFlag">
           {{ viewDataWriter  }}</el-col>
      </el-row>
      <el-row :gutter="20">
        <el-col class="test grid-content bg-purple" :offset="4" :span="6">내용</el-col>
        <el-col class="test" :span="10" v-show="!updateFlag">
           {{ viewDataContents  }}</el-col>
      </el-row> 
      <el-row :gutter="20">
        <el-col class="test grid-content bg-purple" :offset="4" :span="6" style="height:150px">첨부파일</el-col>
        <el-col class="test" :span="10" style="height:150px">
           <div style="padding:3px" v-show="!updateFlag" v-for="(fileName,fileId) in viewDataFile" :key="fileId">
              <button @click="fileDownload(fileName)">{{ fileName.orgFileName  }}</button>
           </div>
      </el-col>
      </el-row>
    </div>

<div v-show="updateFlag" >
      <el-row :gutter="20">
        <el-col class="test grid-content bg-purple" :offset="4" :span="6"> 제목ss</el-col>
        <el-col class="test " :span="10" v-show="updateFlag">
        <input v-model= title></el-col>
      </el-row>
      <el-row :gutter="20">
        <el-col class="test grid-content bg-purple" :offset="4" :span="6">작성자</el-col>
        <el-col class="test"  :span="10" v-show="updateFlag">
        <!-- <input v-model= writer > -->
        {{ viewDataWriter  }}
        </el-col>
      </el-row>
      <el-row :gutter="20">
        <el-col class="test grid-content bg-purple" :offset="4" :span="6">내용</el-col>
        <el-col class="test" :span="10" v-show="updateFlag">
        <input v-model= contents></el-col>
      </el-row> 
      <el-row :gutter="20">
        <el-col class="test grid-content bg-purple" :offset="4" :span="6" style="height:150px">첨부파일</el-col>
        <el-col class="test" :span="10">
           <div style="padding:2px" v-show="updateFlag" v-for="(fileName,fileId) in viewDataFile" :key="fileId">
              <button @click="fileDelete(fileName.fileName)">{{ fileName.orgFileName  }}  삭제</button><br/>
           </div>
            <input type="file" @change="onFileSelected" multiple style="margin:2px;"><br/>
        </el-col>
      </el-row> 
    </div>
    <div>
    <br><br></div>
  <div>
        <el-row>
          <el-button type="primary" round @click="detailUpdate" v-show="!updateFlag">수정</el-button>
          <el-button type="success" round @click="detailClose" v-show="!updateFlag">닫기</el-button>
          <el-button type="danger" round @click="detailDelete(id)" v-show="!updateFlag" >삭제</el-button>
          <el-button type="primary" round @click="updateSave" v-show="updateFlag">저장</el-button>
          <el-button type="danger" round @click="updateCancel(id)" v-show="updateFlag">취소</el-button>
        </el-row><br><br><br>
    </div>
  </div>
</template>
<script>
export default {
  props:{
    detailFlag: Boolean,    //기본값 false
    viewData : Object,
    // border:Boolean,
    viewDataId:Number,
    viewDataTitle:String,
    viewDataContents:String,
    viewDataWriter:String,
    viewDataFile:{
      type:Array,
      default:()=>{
        return{
          boardId:'',
          fileCount:'',
          fileId:'',
          fileName:'',
          fileSize:'',
          files:'',
          orgFileName:''
        }

      }
    },
    viewDataOrgFileName:String,
  },
  data(){
    return{
      data: this.viewData,   //controller에서 가져온 모든 데이터
      id: this.viewDataId,    //id 데이터
      title: this.viewDataTitle,    //title 데이터
      contents: this.viewDataContents,    //contents 데이터
      writer: this.viewDataWriter,   //writer 데이터
      fileName: this.viewDataFile,   //file 데이터
      form:'',    //params값 (title + contents + writer + id)
      updateMove:'',   //update버튼 클릭시 화면이동
      updateFlag: false , 
    fileAdd:[], // 수정화면_ 파일 추가
    fileDeleteVal:'',
    }
  },
  // watch: {
  //   viewData: {
  //     deep: true,
  //     handler(val) {
  //       console.log("text입력 값 :::::::"+val)
  //       this.id = val.data.boardView.id;
  //       this.title = val.data.boardView.title;
  //       this.contents = val.data.boardView.contents;
  //       this.writer = val.data.boardView.writer;
  //     }
  //   }
  // },

  methods:{

  //첨부파일 클릭
  onFileSelected(event){
    console.log("files ::::::::::: "+event.target.files);
    this.fileAdd = event.target.files;
    console.log(this.fileAdd)
  },
  //파일다운로드
  fileDownload(viewDataFile){
    console.log(viewDataFile.fileName);
    console.log(viewDataFile.orgFileName);

    const url = '/api/fileDownload/'+ viewDataFile.orgFileName +"?fileName="+viewDataFile.fileName+"&filePath="+viewDataFile.fileName;
    // const url = '/api/fileDownload/'+ viewDataFile.orgFileName +"?fileName="+viewDataFile.fileName;
    window.open(url,'popupView'); 
  },


// 출처: https://happyman73.tistory.com/36 [작은악마`s Blog]
    // this.$axios.get('/api/fileDownload/'+ viewDataFile.orgFileName,{
    //   params:{
    //     filePath : viewDataFile.filePath,
    //     fileName: viewDataFile.fileName,
    //   },
      
    //   headers: { responseType: 'blob' },
    // })
    // this.$axios.get('/api/fileDownload/'+ viewDataFile.fileName)
   

  // 상세보기(수정버튼)
    detailUpdate(){
      this.detailFlag=true;
      this.updateFlag= true;
    },



    //수정화면(파일삭제)
    fileDelete(val){
     const formData = new FormData();
        formData.append('fileName', val);
      this.$confirm('파일을 삭제하시겠습니까?', '알림', {
          confirmButtonText: 'OK',
          cancelButtonText: 'Cancel',
            type: 'warning'
          }).then((confirmButtonText)=>{
            if(confirmButtonText){
               this.$axios({
                method: "post",   //파일업로드는 put 사용 x
                url: '/api/fileDelete', 
                data: formData,
                headers: { 
                  'Content-Type': 'multipart/form-data'
                }
              })
              .then(()=>{
                this.$message({
                  type: 'success',
                  message: 'fileDelete 완료'
                })
                this.$emit("detailDelete");
            }).catch((error)=>{
                console.log(error)
        })
        }}).catch((error)=>{
          console.log(error)
      })
    },

    // 상세보기(삭제버튼)
    detailDelete(id){
        console.log("삭제 id ============"+id);
        this.$axios.delete('/api/boardDelete2',{
          params:{
          id:id
         }
        })
      .then(() => {
        this.$confirm('게시글을 삭제 하시겠습니까?', '알림', {
          confirmButtonText: 'OK',
          cancelButtonText: 'Cancel',
            type: 'warning'
          }).then(() => {
            this.$message({
              type: 'success',
              message: '삭제되었습니다.'
            });
            this.$emit("detailDelete");
          }).catch(() => {
            this.$message({
              type: 'info',
              message: '삭제가 취소되었습니다'
            });          
        });
      })
      .catch((error)=>{
        console.log(error)
      })
    },
    // 상세보기(닫기버튼)
    detailClose() {
      this.$emit("detailClose");
    },

    // 수정화면(저장버튼)
    updateSave(){
      const formData = new FormData();
        for(let i=0;i < this.fileAdd.length; i++){
          let file= this.fileAdd[i];
          formData.append('files', file);
        }
        formData.append('title', this.title);
        formData.append('contents', this.contents);
        formData.append('writer', this.writer);
        formData.append('id', this.id);

      this.$confirm('게시글을 수정하시겠습니까?', '알림', {
          confirmButtonText: 'OK',
          cancelButtonText: 'Cancel',
            type: 'warning'
          }).then((confirmButtonText)=>{
            if(confirmButtonText){
               this.$axios({
                method: "post",   //파일업로드는 put 사용 x
                url: '/api/boardUpdate2', 
                data: formData,
                headers: { 
                  'Content-Type': 'multipart/form-data'
                   // content-type : 기본값
                  // 'Content-type': 'application/x-www-form-urlencoded',
                }
              })
              .then(()=>{
                this.$message({
                  type: 'success',
                  message: '수정이 완료되었습니다.'
                })
                this.$emit("detailDelete");
            }).catch((error)=>{
                console.log(error)
        })
        }}).catch((error)=>{
          console.log(error)
      })
    },

  // 수정화면: 취소버튼
    updateCancel(){
      this.updateFlag=false;
      this.$emit("detailDelete");
    }
  }
}
</script>
<style scoped>
.test {
  padding: 10px;
  border: 1px solid #EBEEF5;
  height: 100px
}
  .el-col {
    border-radius: 4px;
  }
  .bg-purple-dark {
    background: #99a9bf;
  }
  .bg-purple {
    background: #d3dce6;
  }
  .bg-purple-light {
    background: #e5e9f2;
  }
  .grid-content {
    border-radius: 4px;
    min-height: 36px;
  }
  .row-bg {
    padding: 10px 0;
    background-color: #f9fafc;
}
</style>