<template>
  <div>
    hi
  </div>
</template>

<script>
export default {
  name:'page',
  data(){
    return{
   
    }
  }, 
  created() {
    console.log(this.$route);
  }
};
</script>