<template>
  <div>
<div v-show="!updateFlag" >
      <el-row :gutter="20">
        <el-col class="test grid-content bg-purple" :offset="4" :span="6">제목</el-col>
        <el-col class="test " :span="10" v-show="!updateFlag">
         {{ viewDataTitle  }}</el-col>
      </el-row>
      <el-row :gutter="20">
        <el-col class="test grid-content bg-purple" :offset="4" :span="6">작성자</el-col>
        <el-col class="test" :span="10" v-show="!updateFlag">
           {{ viewDataWriter  }}</el-col>
      </el-row>
      <el-row :gutter="20">
        <el-col class="test grid-content bg-purple" :offset="4" :span="6">내용</el-col>
        <el-col class="test" :span="10" v-show="!updateFlag">
           {{ viewDataContents  }}</el-col>
      </el-row> 
    </div>

<div v-show="updateFlag" >
      <el-row :gutter="20">
        <el-col class="test grid-content bg-purple" :offset="4" :span="6"> 제목ss</el-col>
        <el-col class="test " :span="10" v-show="updateFlag">
        <input v-model= title></el-col>
      </el-row>
      <el-row :gutter="20">
        <el-col class="test grid-content bg-purple" :offset="4" :span="6">작성자</el-col>
        <el-col class="test"  :span="10" v-show="updateFlag">
        <input v-model= writer></el-col>
      </el-row>
      <el-row :gutter="20">
        <el-col class="test grid-content bg-purple" :offset="4" :span="6">내용</el-col>
        <el-col class="test" :span="10" v-show="updateFlag">
        <input v-model= contents></el-col>
      </el-row> 
    </div>
    <div>
    <br><br></div>
  <div>
        <el-row>
          <el-button type="primary" round @click="detailUpdate" v-show="!updateFlag">수정</el-button>
          <el-button type="success" round @click="detailClose" v-show="!updateFlag">닫기</el-button>
          <el-button type="danger" round @click="detailDelete(id)" v-show="!updateFlag" >삭제</el-button>
          <el-button type="primary" round @click="updateSave" v-show="updateFlag">저장</el-button>
          <el-button type="danger" round @click="updateCancel()" v-show="updateFlag">취소</el-button>
        </el-row><br><br><br>
    </div>
    <!-- <replyWrite/> -->
  </div>
</template>
<script>
// import replyWrite from '@/views/reply/replyWrite.vue'
export default {
  // components:{
  //   replyWrite
  // },
  props:{
    detailFlag: Boolean,    //기본값 false
    viewData : Object,
    // border:Boolean,
    viewDataId:Number,
    viewDataTitle:String,
    viewDataContents:String,
    viewDataWriter:String
  },
  data(){
    return{
      data: this.viewData,   //controller에서 가져온 모든 데이터
      id: this.viewDataId,    //id 데이터
      title: this.viewDataTitle,    //title 데이터
      contents: this.viewDataContents,    //contents 데이터
      writer: this.viewDataWriter,   //writer 데이터
      form:'',    //params값 (title + contents + writer + id)
      updateMove:'',   //update버튼 클릭시 화면이동
      updateFlag: false     
    }
  },
  // watch: {
  //   viewData: {
  //     deep: true,
  //     handler(val) {
  //       console.log("text입력 값 :::::::"+val)
  //       this.id = val.data.boardView.id;
  //       this.title = val.data.boardView.title;
  //       this.contents = val.data.boardView.contents;
  //       this.writer = val.data.boardView.writer;
  //     }
  //   }
  // },
  methods:{
  // 상세보기: 수정버튼
    detailUpdate(){
      this.detailFlag=true;
      this.updateFlag= true;
    },
    // 상세보기: 삭제버튼
    detailDelete(id){
      console.log("삭제 id ============"+id);
      this.$confirm('게시글을 삭제 하시겠습니까?', '알림', {
        confirmButtonText: 'OK',
        cancelButtonText: 'Cancel',
        type: 'warning'
      }).then((confirmButtonText)=>{
          if(confirmButtonText){
            this.$axios.delete('/api/boardDelete',{
              params:{
              id:id
              }
            })
            this.$message({
              type: 'success',
              message: '삭제되었습니다.'
            });
            this.$emit("detailDelete");
          }
      }).catch((error)=>{
          console.log(error)
      })
    },
  // 상세보기: 닫기버튼
    detailClose() {
      this.$emit("detailClose");
    },
    // 수정화면: 저장버튼
    updateSave(){
      this.form={
      title:this.title,
      contents:this.contents,
      writer:this.writer,
      id: this.id
    };
    this.$confirm('게시글을 수정하시겠습니까?', '알림', {
      confirmButtonText: 'OK',
      cancelButtonText: 'Cancel',
        type: 'warning'
    }).then((confirmButtonText)=>{
      if(confirmButtonText){
        this.$axios.put('/api/boardUpdate', this.form)
        .then((response)=>{
          if(response.status==200){
            this.$message({
              type: 'success',
              message: '수정이 완료되었습니다.'
            });
            this.$emit("updateMove")
          }
        })
      }
    })
    .catch((error)=>{
      console.log(error)
      })
    },


  // 수정화면: 취소버튼
    updateCancel(){
      this.updateFlag=false;
      // this.$emit("updateCancel")
    }
  }
}
</script>
<style scoped>
.test {
  padding: 10px;
  border: 1px solid #EBEEF5;
  height: 100px
}
  .el-col {
    border-radius: 4px;
  }
  .bg-purple-dark {
    background: #99a9bf;
  }
  .bg-purple {
    background: #d3dce6;
  }
  .bg-purple-light {
    background: #e5e9f2;
  }
  .grid-content {
    border-radius: 4px;
    min-height: 36px;
  }
  .row-bg {
    padding: 10px 0;
    background-color: #f9fafc;
}
</style>