<template>
  <div>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.2/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.2/css/bootstrap-theme.min.css">
    <ul class="pagination justify-content-center">
      <li v-if="prev">
        <router-link :to="`/pageList?page=${ (startPageIndex - 1) * listRowCount }`" @click.native="movePage(startPageIndex - 1)">
          <span aria-hidden="true">&laquo;</span>
        </router-link>
      </li>

      <li v-for="index in endPageIndex-startPageIndex + 1 " :key="index" :class="{active:( (startPageIndex + index - 1) == currentPageIndex)}">
        <router-link :to="`/pageList?page=${ (startPageIndex + index - 1) * listRowCount }`"  @click.native="movePage(startPageIndex + index - 1)">{{ startPageIndex + index - 1 }}</router-link>
      </li>

      <li  v-if="next">
        <router-link :to="`/pageList?page=${ (endPageIndex + 1) * listRowCount }`" @click.native="movePage(endPageIndex + 1)">
          <span aria-hidden="false">&raquo;</span>
        </router-link>
      </li>
    </ul>

    <!-- 
    각페이지 항목수
    전체 게시글 수
    전체 페이지수
    현재 페이지수

    페이지 링크 개수
    형세, prev size next 
    -->
      <!-- :pager-count="10"    -->
      <!-- :pager-count="pageLinkCount"    -->
        <el-pagination
      :page-size="listRowCount"   
      :total="totalListItemCount"
      :page-count="pageCount"
      :current-page="currentPageIndex"
            :page-sizes="[5, 10, 15, 20]"


      layout="prev, pager, next"
      >
      <!-- @prev-click="prevClick"  -->
      <!-- @next-click="nextClick" -->
    </el-pagination>
  </div>
</template>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.2/js/bootstrap.min.js"></script>
<script>
export default {
  name:'page',
  props:{
    listRowCount2:Number,
    startPageIndex2:Number,
  },
  data(){
    return{
    // prevClick:"`/pageList?count=${ (startPageIndex - 1) * listRowCount }`",
    // nextClick:"`/pageList?count=${ (endPageIndex + 1) * listRowCount }` ",
    // currentChange:"` /pageList?count=${ (startPageIndex + (endPageIndex-startPageIndex + 1) - 1) * listRowCount }`",

      listRowCount:this.listRowCount2,         //페이지당 게시글 출력 수
      pageLinkCount:5,     ///페이지 링크 보여지는 수
      
      totalListItemCount:'',     // 전체 게시글 수
      startPageIndex:this.startPageIndex2, // 페이징시작번호 (1, 11, 21...)
      endPageIndex:'', // 페이징끝번호 (9,19,29...)

      pageCount:'',      //전체 페이지 수
      currentPageIndex: 0,      //현재 페이지번호 

      prev:false,
      next:false,

       currentPage1: 5,
        currentPage2: 5,
        currentPage3: 5,
        currentPage4: 4
    }
  },
  created() {
    this.initComponent();
  },
  methods: {
     handleSizeChange(val) {
        console.log(`${val} items per page`);
      },
      handleCurrentChange(val) {
        console.log(`current page: ${val}`);
      },
    initComponent(){
  console.log(this.listRowCount)
  console.log(this.startPageIndex)
      this.$axios.get("/api/boardCount")
        .then(({ data }) => {
  console.log("전체 게시글 수=====================")
  console.log(data)
          this.totalListItemCount = data;     //전체 데이터 수
          this.initUI();
        })
        .catch(() => {
          alert("에러가 발생했습니다.");
        });
    },
    initUI(){
      // this.pageCount = Math.ceil(this.totalListItemCount/this.listRowCount);        //전체 몇 페이지 인지 (전체/페이지 게시글 수)
      this.pageCount =Math.ceil(this.totalListItemCount/this.listRowCount)+1;        //전체 몇 페이지 인지 (전체/페이지 게시글 수)
        console.log("몇 페이지까지 있니==================")
        console.log(this.pageCount)

      if( (this.currentPageIndex % this.pageLinkCount) == 0 ){  //10, 20...맨마지막
      this.endPageIndex =Math.ceil((this.currentPageIndex / this.pageLinkCount)-1)*this.pageLinkCount + this.pageLinkCount
        }else{
        this.endPageIndex = Math.ceil (this.currentPageIndex / this.pageLinkCount)*this.pageLinkCount + this.pageLinkCount;
      }
        console.log("endPageIndex==================")
        console.log(this.endPageIndex)
        console.log("현재 페이지는 ==================")
        console.log(this.currentPageIndex)

        // if( (this.currentPageIndex % this.pageLinkCount) == 0 ){
        //   this.startPageIndex = ((this.currentPageIndex / this.pageLinkCount)-1)*this.pageLinkCount + 1
        // }else{
        this.startPageIndex=Math.ceil(this.endPageIndex-this.listRowCount)+1
        this.startPageIndex = (this.currentPageIndex / this.pageLinkCount)*this.pageLinkCount + 1
        // }
        console.log("startPageIndex==================")
        console.log(this.startPageIndex)

      if( this.currentPageIndex <= this.pageLinkCount ){
        this.prev = false;
      }else{
        this.prev = true;
      }

      if(this.endPageIndex >= this.pageCount){
        this.endPageIndex = this.pageCount;
        this.next = false;
      }else{
        this.next = true;
      }
      },
    movePage( param ) {
        console.log("movePage ===============================")
        console.log(param)
        this.currentPageIndex = param;      //파라미터 받은 값이 현재 페이지
        this.initComponent();
      // this.pageInit();
      },
  }
};
</script>