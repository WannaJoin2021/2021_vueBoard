<template>
  <div class="replyWrite">
    <h4>댓글작성</h4>
    <!-- <div style="margin: 20px 0;"></div> -->
      <div class="demo-input-size">
        <h4>글번호 {{id}}</h4>
          <el-input
              type="textarea"
              placeholder="Please input"
              v-model="textarea"
              maxlength="30"
              show-word-limit
              style="text-align:center; width:600px; height:200px;"
          /> 
          <!-- <el-input
              size="small"
              disabled
              v-model="writer"
              style="text-align:center; width:100px; height:350px;"
          /> -->
        <el-row>
          <el-button type="primary" icon="el-icon-edit" circle @click="replySave"></el-button>
          <!-- <el-button type="warning" icon="el-icon-check" circle @click="writeCancel"></el-button> -->
        </el-row>
        </div>  
      <div>
    </div>
  </div>

            <!-- <el-button type="primary" round  @click="writeSave">저장</el-button>
            <el-button type="danger" round @click="writeCancel">취소</el-button> -->
  <!-- </div> -->
</template>

<script>
export default {
  props:{
    id
  },
  name: "replyWrite",
    data(){
      return {
        id:this.id,
        textarea: '',
        reply:'',
        writer:this.$store.state.id,
      }
    },
    methods:{
      // 글작성: 저장버튼
      replySave(){
        this.$axios.post('/api/replyInsert', {
          contents:this.textarea,
          writer:this.writer,
          id:this.id
        })
          .then((response)=>{
            console.log(response);
            if(response.status==200){
              // this.$router.push({path:'/boardList'})
              this.$router.push({path:'/boardList'})
            }
          })
          .catch(()=>{
            console.log(error)
          })
      }
    }
  } 
</script>
