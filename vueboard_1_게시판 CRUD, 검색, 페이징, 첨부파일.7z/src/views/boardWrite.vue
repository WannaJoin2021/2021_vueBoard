<template>
  <div class="boardWrite">
  <h1>게시글작성</h1>
    <table border="1" width="45%" style="margin-left: auto; margin-right: auto;">
      <thead>
        <tr>
          <th width="20%" height="100">제목</th>
          <th width="80%" height="100"><input v-model="title" style="text-align:center; width:95%; height:80%;"></th>
        </tr>
        <tr>
          <th width="20%" height="300">내용</th>
          <th width="80%" height="300"><input v-model="contents" style="text-align:center; width:95%; height:90%;"></th>
        </tr>
        <tr>
          <th width="20%" height="100">작성자</th>
          <th width="80%" height="100"><input v-model="writer" disabled style="text-align:center; width:95%; height:80%;">
          </th>
        </tr>
         <tr>
          <th width="10%" height="100">첨부파일</th>
          <th>
           <input type="file" @change="onFileSelected" multiple style="margin:2px;"><br/>
           <!-- <button  @click="submitUpload">upload</button> -->
          </th>
        </tr>
      </thead>
    </table><br/>
          <el-row>
          <el-button type="primary" round  @click="writeSave">저장</el-button>
          <el-button type="danger" round @click="writeCancel">취소</el-button>
        </el-row>
  </div>
</template>

<script>
export default {
  name: "boardWrite",
    data(){
      return {
        selectedFile:'',
        FileList:[],
        id:'',
        title:'',
        contents:'',
        writer:this.$store.state.id,
      }
    },
    methods:{
      //첨부파일 클릭
      onFileSelected(event){
        console.log(event);
        console.log("files ::::::::::: "+event.target.files);
        // this.selectedFile = event.target.files[0];
        this.FileList = event.target.files;
        console.log(this.FileList)
      },
      // 글작성(저장버튼)
      writeSave(){
        const formData = new FormData();
        for(let i=0;i < this.FileList.length; i++){
          let file= this.FileList[i];
          console.log(file);
        formData.append('files', file);
        }
        // formData.append('files', this.selectedFile);
        formData.append('title', this.title);
        formData.append('contents', this.contents);
        formData.append('writer', this.writer);

        this.$confirm('게시글을 작성하시겠습니까?', '알림', {
          confirmButtonText: 'OK',
          cancelButtonText: 'Cancel',
            type: 'warning'
          }).then((confirmButtonText)=>{
            if(confirmButtonText){
               this.$axios({
                method: "post",
                url: '/api/boardInsert', 
                data: formData,
                headers: { 
                  'Content-Type': 'multipart/form-data'
                }
                  }).then(()=>{
                    this.$message({
                      type: 'success',
                      message: '게시글이 등록 되었습니다.'
                    })
                  this.$router.push({path:'/perPageCount'})
                }).catch((error)=>{
                    console.log(error)
          })
          }}).catch((error)=>{
            console.log(error)
        })
    },
      // 글작성(취소버튼)
      writeCancel(){
        this.$router.push({path:'/boardList',query:this.body})
          // this.$router.push({path:'/boardList',query:this.body})
          // this.$axios.get(this.url+'/boardListAll')
        .then(() => {
          this.updateFlag=true;
          this.vshow=false;
        })
          .catch((error)=>{
          console.log(error)
        })
      },
  } //methods
}//export
</script>