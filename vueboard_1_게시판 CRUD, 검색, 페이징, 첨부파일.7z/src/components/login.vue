<template>
  <div>
    <p></p>
    <div>
      <el-form :model="ruleForm" status-icon ref="ruleForm" label-width="120PX" style="width: 50%; margin:auto;" class="demo-ruleForm">
        <el-form-item label="id" >
          <el-input v-model="ruleForm.id" size="small"  placeholder="아이디를 입력해주세요"></el-input>
        </el-form-item>
        
        <el-form-item label="Password" prop="pass">
          <el-input type="password" v-model="ruleForm.pass" autocomplete="off" placeholder="패스워드를 입력해주세요"></el-input>
        </el-form-item>

        <el-form-item>
          <el-button type="primary" @click="loginSumit('ruleForm')">Submit</el-button>
          <el-button @click="resetForm('ruleForm')">Reset</el-button>
        </el-form-item>
      </el-form>
    </div>
  </div>
</template>
<script>
  export default {
    data() {
      return {
        ruleForm: {
          id: '',
          pass: '',
        },
        // token:'',
        setId:'',
      };
    },
    
    methods: { 
      loginSumit(){
        if(this.ruleForm.id == null || this.ruleForm.id ==''){
          alert("아이디를 입력해주세요")
        }else if(this.ruleForm.pass == null || this.ruleForm.pass ==''){
          alert("패스워드를 입력해주세요")
        }else{       
          this.$axios.get('/api/loginCheck',{
            params:{
              id:this.ruleForm.id,
              password:this.ruleForm.pass,
            }
          })
          .then((response)=>{
            console.log(response);
            console.log("============================");

            if(response.data==''||response.data==null){
                alert("아이디 또는 패스워드를 확인해주세요")
              // this.$router.push("/login");
              // 같은 페이지 에러발생, 커서 이동으로 바꾸기
            }
            else{
              alert("로그인 성공")
              console.log("id>>>>>>>>>>>",response.data.id)
              // console.log("token>>>>>>>>>>>",response.data.token)
              this.$store.commit('setId', response.data.id)
              // this.$store.commit('setToken', response.data.setToken)
              this.$router.push("/");
            }
          })
        }
      },
      resetForm(formName) {
        this.$refs[formName].resetFields();
      },
      initForm(){
        this.id="";
        this.password="";
      }
    }
  }
</script>