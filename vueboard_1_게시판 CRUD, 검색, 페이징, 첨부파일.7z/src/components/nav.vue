<template>
  <div id="app">
      <div id="nav">
    <el-menu
      :default-active="activeIndex2"
      class="el-menu-demo"
      mode="horizontal"
      @select="handleSelect"
      background-color="#545c64"
      text-color="#fff"
      active-text-color="#ffd04b">

      <el-menu-item index="0"><img alt="Vue logo" src="@/assets/logo.png" width="30"></el-menu-item>

      <el-submenu index="1">
        <template slot="title">Home</template>
        <router-link to="/"><el-menu-item index="1-1">Home</el-menu-item></router-link>
      </el-submenu>

      <el-submenu index="2">
        <template slot="title">게시판</template>
      
        <!-- <template v-if="isUserLogin"> -->
          <router-link to="/perPageCount"><el-menu-item index="2-1">게시글 목록</el-menu-item></router-link>
          <router-link to="/boardWrite"><el-menu-item index="2-2">게시글 작성</el-menu-item></router-link>
        <!-- </template> -->
        <!-- <template v-else> -->
          <!-- <el-menu-item index="2-0">로그인 후 사용</el-menu-item> -->
        <!-- </template> -->
      </el-submenu>

        <el-submenu index="3">

        <template v-if="isUserLogin">
                  <template slot="title">로그아웃</template>
          <el-menu-item index="3-2"><a href="javascript:;" v-on:click="logOut">로그아웃</a></el-menu-item>
        </template>

        <template v-else>
        <template slot="title">로그인</template>
          <router-link to="/signUp"><el-menu-item index="3-1">회원가입</el-menu-item></router-link>
          <router-link to="/login"><el-menu-item index="3-2">로그인</el-menu-item></router-link>
        </template>

      </el-submenu>
        <el-submenu index="4">
        <template slot="title">링크</template>
        <el-menu-item index="4-1"><a href="http://www.google.com" target="_blank">google</a></el-menu-item>
        <el-menu-item index="4-2"><a href="http://www.naver.com" target="_blank">naver</a></el-menu-item>
      </el-submenu>
    </el-menu>
      </div>
  </div>
</template>
<script>
  import login from "@/components/login.vue"

  export default {
    components:{
      login
    },
    data() {
      return {
        activeIndex: '1',
        activeIndex2: '1'
      };
    },
    // computed는 반응형 getters이다. return 을 해주는게 기본 원칙
    computed:{
      isUserLogin() {
        return this.$store.getters.isUserLogin;
      },
    },
    methods: {
      handleSelect(key, keyPath) {
        console.log(key, keyPath);
      },
      logOut(){
        this.$store.commit('logOut');
        this.$router.push("/");

      }
    }
  }
</script>