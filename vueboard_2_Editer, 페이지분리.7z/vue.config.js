module.exports = {
  lintOnSave: false,
  devServer: {
    // historyApiFallback: true,
    proxy: { // proxyTable 설정
      '/api': {
        target: "http://localhost:8080",
        changeOrigin: true,
        pathRewrite: {
          "^/api": ""
        }
        // logLevel: 'debug' // this what you want
      }
    }
  }
}
