<template>
  <div id="app"><br><br><br>
    <!-- <div id="nav">
      <img alt="Vue logo" src="@/assets/logo.png" width="30">|
      <router-link to="/">Home</router-link> |
      <router-link to="/boardList">게시판</router-link> |
      <router-link to="/signUp">회원가입</router-link> |
      <router-link to="/login">login</router-link> |
      <router-link to="/boardView2">상세</router-link> |
    </div> -->
      <navMenu/>
    <router-view/>

  </div>
</template>

<script>
import navMenu from "@/components/nav.vue"
export default {
  components:{
    navMenu
  }
}
</script>
<style lang="scss">
  @import "../node_modules/ag-grid-community/dist/styles/ag-grid.css";
  @import "../node_modules/ag-grid-community/dist/styles/ag-theme-alpine.css";

#app {
  font-family: Avenir, Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  text-align: center;
  color: #2c3e50;
}

#nav {
  padding: 30px;
  a {
    font-weight: bold;
    color: #2c3e50;

    &.router-link-exact-active {
      color: #42b983;
    }
  }
}
</style>
