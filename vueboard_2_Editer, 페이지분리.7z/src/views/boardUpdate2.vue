<template>
  <div>
    <div>
      <el-form abel-width="120px" label-position="right" style="width: 70%; margin:auto;">
        <el-form-item label="★ 글수정 ★" ></el-form-item>
        <el-form-item label="제목" >
          <el-input v-model="title" size="small"  ></el-input>
        </el-form-item>
        <el-form-item label="작성자" >
          <el-input v-model="writer" size="small" disabled ></el-input>
        </el-form-item>
        <el-form-item label="내용">
        </el-form-item>
          <editor
            ref="eContents"
            height="500px"
            initialEditType="wysiwyg"
          /><br>
        <el-form-item label="첨부파일"></el-form-item>
          <div class="tui-editor-contents" style="height:140px" ><br>
            <span  v-for="(file,fileId) in fileInfo" :key="fileId">
              <el-button type="success" style="margin:2px;" @click="fileDelete(file.fileName)">{{ file.orgFileName}} 삭제</el-button>
            </span>
            <div>
            <input type="file" @change="onFileSelect" multiple style="padding:15px;"><br/>
           </div>
          </div>
      </el-form>
    </div>
    <div><br>
      <el-row>
        <el-button type="primary" round @click="updateSave" >저장</el-button>
        <el-button type="danger" round @click="updateCancel" >취소</el-button>
      </el-row><br><br><br>
    </div>
  </div>
</template>
<script>
import { Editor } from '@toast-ui/vue-editor';
import 'codemirror/lib/codemirror.css'; // Editor's Dependency Style
import '@toast-ui/editor/dist/toastui-editor.css';// Editor's Stylex

export default {
  name:"boardUpdate2",
  components: {
    editor: Editor
  },
  data(){
    return{
      boardList:'',
      id:'',
      title:'',
      contents:'',
      writer:'',
      fileInfo:'',
      fileAdd:[], // 수정화면_ 파일 추가
      }
  },
  created(){
    console.log("======게시글수정=======")
      console.log("routerId>>",this.$route.query)
      this.id=this.$route.query.id

      this.$axios.get('/api/boardView/'+this.id)
        .then((response)=>{
          this.title=response.data.boardView.title;
          this.contents=response.data.boardView.contents;
          this.writer=response.data.boardView.writer;
          this.fileInfo=response.data.fileView;
          this.$refs.eContents.invoke("setMarkdown", this.contents);

        }).catch(function (e) {
          console.error(e)                
      })
  },

  methods:{
    //첨부파일 클릭
    onFileSelect(event){
      console.log("files ::::::::::: "+event.target.files);
      this.fileAdd = event.target.files;
      console.log(this.fileAdd)
    },

    //수정화면(파일삭제)
    fileDelete(fileName){
      const formData = new FormData();
      formData.append('fileName', fileName);
      this.$confirm('파일을 삭제하시겠습니까?', '알림', {
        confirmButtonText: 'OK',
        cancelButtonText: 'Cancel',
          type: 'warning'
        }).then((confirmButtonText)=>{
          if(confirmButtonText){
            this.$axios({
            method: "post",   //파일업로드는 put 사용 x
            url: '/api/fileDelete', 
            data: formData,
            headers: { 
              'Content-Type': 'multipart/form-data'
            }
          })
          .then(()=>{
            this.$emit("detailDelete");
            this.$message({
              type: 'success',
              message: '파일삭제 완료'
            })
          this.$router.push({path:'/perPageCount'})
          this.$emit("detailDelete");
        }).catch((error)=>{
            console.log(error)
        })
        }}).catch(()=>{
          this.$message({
          type: 'info',
          message: '파일삭제가 취소되었습니다'
        })
      })
    },
    // 수정화면(저장버튼)
    updateSave(){
      console.log("수정버튼:::::::::::")
      const formData = new FormData();
      for(let i=0;i < this.fileAdd.length; i++){
        let file= this.fileAdd[i];
        formData.append('files', file);
      }
      formData.append('id', this.id);
      formData.append('title', this.title);
      formData.append('writer', this.writer);
      this.contents = this.$refs.eContents.invoke('getMarkdown');
      formData.append('contents', this.contents);

      console.log("eContents>>>>>>>>>>",this.$refs.eContents.invoke('getMarkdown'))
      console.log("eContents>>>>>>>>>>",this.$refs.eContents.invoke('getHtml'))     //html타입

      this.$confirm('게시글을 수정하시겠습니까?', '알림', {
        confirmButtonText: 'OK',
        cancelButtonText: 'Cancel',
          type: 'warning'
        }).then((confirmButtonText)=>{
          if(confirmButtonText){
              this.$axios({
              method: "post",   //파일업로드는 put 사용 x
              url: '/api/boardUpdate2', 
              data: formData,
              headers: { 
                'Content-Type': 'multipart/form-data'
                // 'Content-type': 'application/x-www-form-urlencoded',   : 기본값
              }
            })
            .then(()=>{
              this.$message({
                type: 'success',
                message: '수정이 완료되었습니다.'
              })
            this.$router.push({path:'/perPageCount'})
              this.$emit("detailDelete");
          }).catch((error)=>{
              console.log(error)
          })
        }}).catch(()=>{
            this.$message({
              type: 'info',
              message: '수정이 취소되었습니다'
         })
      })
    },

  // 수정화면: 취소버튼
    updateCancel(){
      this.$router.push({path:'/perPageCount'})
      this.$emit("detailDelete");
    }
  }
}
</script>
<style scoped>
.tui-editor-contents{
    margin: 10px 0;
    background-color: #F5F7FA;
    border-color: #E4E7ED;
    color: #C0C4CC;
    cursor: not-allowed;
    border: 1px solid #E4E7ED;
  }
</style>
<style scoped>
  .test {
    padding: 10px;
    border: 1px solid #EBEEF5;
    height: 100px
  }
  .el-col {
    border-radius: 4px;
  }
  .bg-purple-dark {
    background: #99a9bf;
  }
  .bg-purple {
    background: #d3dce6;
  }
  .bg-purple-light {
    background: #e5e9f2;
  }
  .grid-content {
    border-radius: 4px;
    min-height: 36px;
  }
  .row-bg {
    padding: 10px 0;
    background-color: #f9fafc;
  }
</style>