<template>
  <div>
    <el-form abel-width="120px" label-position="right" style="width: 70%; margin:auto;">
      <el-form-item label="★ 글작성 ★" ></el-form-item>
      <el-form-item label="제목" >
        <el-input  v-model="title" size="small" placeholder="제목을 입력해주세요"></el-input>
      </el-form-item>
      <el-form-item label="작성자" >
        <el-input v-model="writer" size="small" disabled ></el-input>
      </el-form-item>
      <el-form-item label="내용">
        <editor
          :initialValue="editorText"
          :options="editorOptions"
          height="500px"
          initialEditType="wysiwyg"
          previewStyle="vertical"
          ref="eContents"
          v-model="contents"
          />  
      </el-form-item>
      <el-form-item label="첨부파일"  style="height:70px">
        <input type="file" @change="onFileSelect" multiple style="margin:2px;"><br/>
      </el-form-item>
    </el-form>
      <el-row>
      <el-button type="primary" round  @click="writeSave">저장</el-button>
      <el-button type="danger" round @click="writeCancel">취소</el-button>
    </el-row><br><br><br><br><br><br>
  </div>
</template>

<script>
import { Editor } from '@toast-ui/vue-editor';
import 'codemirror/lib/codemirror.css'; // Editor's Dependency Style
import '@toast-ui/editor/dist/toastui-editor.css';// Editor's Style

export default {
  components: { 
    editor: Editor
  },

  name: "boardWrite2",
  data(){
    return {
      editorText: null,
      editorOptions: {
        hideModeSwitch: true
      },
      selectedFile:'',
      FileList:[],
      title:'',
      contents:'',
      writer:this.$store.state.id,
      // eContents:'',
    }
  },
  methods:{
    //첨부파일 클릭
    onFileSelect(event){
      console.log(event);
      console.log("files ::::::::::: "+event.target.files);
      // this.selectedFile = event.target.files[0];
      this.FileList = event.target.files;
      console.log(this.FileList)
    },

    // 글작성(저장버튼)
    writeSave(){
      const formData = new FormData();
      for(let i=0;i < this.FileList.length; i++){
        let file= this.FileList[i];
        console.log(file);
        formData.append('files', file);
      // formData.append('files', this.selectedFile);   //단일처리
      }
        formData.append('title', this.title);
        formData.append('writer', this.writer);
        this.contents = this.$refs.eContents.invoke('getMarkdown');
        formData.append('contents', this.contents);

        console.log("eContents>>>>>>>>>>",this.$refs.eContents.invoke('getMarkdown'))
        console.log("eContents>>>>>>>>>>",this.$refs.eContents.invoke('getHtml'))     //html타입

      this.$confirm('게시글을 작성하시겠습니까?', '알림', {
        confirmButtonText: 'OK',
        cancelButtonText: 'Cancel',
          type: 'warning'
      }).then((confirmButtonText)=>{
        if(confirmButtonText){
          this.$axios({
          method: "post",
          url: '/api/boardInsert', 
          data: formData,
          headers: { 
            'Content-Type': 'multipart/form-data'
          }
          }).then(()=>{
            this.$message({
              type: 'success',
              message: '게시글이 등록 되었습니다.'
            })
          this.$router.push({path:'/perPageCount'})
          this.$emit("detailDelete");
          }).catch((error)=>{
              console.log(error)
          })
        }}).catch(()=>{
            this.$message({
            type: 'info',
            message: '글등록이 취소되었습니다'
        })
      })
    },
    // 글작성(취소버튼)
    writeCancel(){
      this.$router.push({path:'/perPageCount',query:this.body})
        // this.$router.push({path:'/boardList',query:this.body})
        // this.$axios.get(this.url+'/boardListAll')
      .then(() => {
        this.updateFlag=true;
        this.vshow=false;
      }).catch((error)=>{
        console.log(error)
      })
    },
  } //methods
}//export
</script>

<style scoped>
  .myeditor{
  background-color: mistyrose;
  }
</style>