<template>
  <div>
    <div>
        <el-form abel-width="120px" label-position="right" style="width: 70%; margin:auto;">
          <el-form-item label="★ 게시글보기 ★" >
          </el-form-item>
          <el-form-item label="제목" >
            <el-input v-model="title" size="small" disabled  ></el-input>
          </el-form-item>
          <el-form-item label="작성자" >
            <el-input v-model="writer" size="small" disabled></el-input>
          </el-form-item>
          <el-form-item label="내용"/>
            <div class="tui-editor-contents" style="height:500px">
              <viewer 
                ref="viewer"
                height="500px">
              </viewer>
            </div>
        <el-form-item label="첨부파일" />
          <div class="tui-editor-contents" style="height:90px" ><br>
          <span style="text-align:center; padding:10px; " v-for="(file,fileId) in fileInfo " :key="fileId">
            <el-button type="success" @click="fileDownload(file)">{{ file.orgFileName  }}</el-button>
          </span>
          </div>
      </el-form>
    </div>
    <div><br><br><br>
      <el-row>
          <el-button type="primary" round @click="detailUpdate(id)" >수정</el-button>
          <el-button type="danger" round @click="detailDelete(id)"  >삭제</el-button>
      </el-row><br><br><br>
    </div>
  </div>
</template>
<script>
import { Viewer } from '@toast-ui/vue-editor';
import "codemirror/lib/codemirror.css";
import '@toast-ui/editor/dist/toastui-editor-viewer.css';

export default {
  name:"boardView2",
  components: {
    viewer: Viewer,
  },
  data(){
    return{
      boardList:'',
      id:'',
      title:'',
      contents:'',
      writer:'',
      fileInfo:'',
      orgFileName:'',
      fileAdd:[], // 수정화면_ 파일 추가
    }
  },
  created() {
    console.log("create");
  },
  mounted(){
    console.log("======게시글보기=======")
    console.log("routerId>>",this.$route.query.id)
    this.id=this.$route.query.id

    this.$axios.get('/api/boardView/'+this.id)
      .then((response)=>{
        // this.boardList = response.data.boardView;   //contents 출력시 필요

        this.title = response.data.boardView.title;
        this.contents = response.data.boardView.contents;
        this.writer = response.data.boardView.writer;
        this.fileInfo  = response.data.fileView;
        this.$refs.viewer.invoke("setMarkdown", this.contents);

        // console.log("contents>>>>>", this.$refs.viewer);       // view 기능
      }).catch(function (e) {
        console.error(e)                
      })
    },

  methods:{
  //파일다운로드
    fileDownload(file){
      console.log(file.fileName);
      console.log(file.orgFileName);
      console.log(file.filePath);

      //새창을 열면 다음 url로 이동하겠다
      const url = '/api/fileDownload/'+ file.orgFileName +"?fileName="+file.fileName;
      window.open(url,'popupView'); 
    },

    // 상세보기(수정버튼)
    detailUpdate(id){
      console.log(id);
      this.$router.push({path:'/boardUpdate',query:{id:id}
      })
    },

    // 상세보기(삭제버튼)
    detailDelete(id){
      this.$confirm('게시글을 삭제 하시겠습니까?', '알림', {
        confirmButtonText: 'OK',
          cancelButtonText: 'Cancel',
            type: 'warning'
          }).then((confirmButtonText) => {
            if(confirmButtonText){
              this.$axios.delete('/api/boardDelete2',{
                params:{
                  id:id
               }
            }).then(()=>{
              console.log("detailDelete::>>>"+id)
              this.$message({
                type: 'success',
                message: '삭제되었습니다.'
            });
              this.$router.push({path:'/perPageCount'})
              this.$emit("detailDelete");
            }).catch(() => {
                console.log(error)
              })          
          }}).catch(()=>{
            this.$message({
              type: 'info',
              message: '삭제가 취소되었습니다'
         })
      })
    },
  }
}
</script>
<style scoped>
  .tui-editor-contents{
    margin: 10px 0;
    background-color: #F5F7FA;
    border-color: #E4E7ED;
    color: #C0C4CC;
    cursor: not-allowed;
    border: 1px solid #E4E7ED;
  }
</style>
<style scoped>
  .test {
    padding: 10px;
    border: 1px solid #EBEEF5;
    height: 100px
  }
  .el-col {
    border-radius: 4px;
  }
  .bg-purple-dark {
    background: #99a9bf;
  }
  .bg-purple {
    background: #d3dce6;
  }
  .bg-purple-light {
    background: #e5e9f2;
  }
  .grid-content {
    border-radius: 4px;
    min-height: 36px;
  }
  .row-bg {
    padding: 10px 0;
    background-color: #f9fafc;
  }

</style>