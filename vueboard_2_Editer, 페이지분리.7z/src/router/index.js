import Vue from 'vue'
import VueRouter from 'vue-router'

Vue.use(VueRouter)

const routes = [
  {
    path: '/',
    name: 'Home',
    component: () => import('@/views/Home')
  },
  // {
  //   path: '/a/:id',
  //   name: 'test',
  //   component: () => import('@/views/test')
  // },
  {
    //게시글리스트
    path: '/perPageCount',
    name: 'perPageCount',
    component:  () => import('@/views/boardList2')
  },
  {
    //게시글작성
    path: '/boardWrite',
    name: 'boardWrite',
    component:  () => import('@/views/boardWrite2')
  },
  {
    //게시글상세보기
    path: '/boardView', 
    name: 'boardView',
    component:  () => import('@/views/boardView2')
  },
  {
    //게시글수정
    path: '/boardUpdate', 
    name: 'boardUpdate',
    component:  () => import('@/views/boardUpdate2')
  },
  {
    //회원가입
    path: '/signUp',
    name: 'signUp',
    component:  () => import('@/components/signUp')
  },
  {
     //로그인
     path: '/login',
     name: 'login',
     component:  () => import('@/components/login')
   },

]

const router = new VueRouter({
  mode: 'history',
  base: process.env.BASE_URL,
  routes
})

export default router
